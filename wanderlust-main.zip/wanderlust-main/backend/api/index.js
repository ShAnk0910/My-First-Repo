import app from '../app.js';
export default app;
console.log('ameer jafar');
